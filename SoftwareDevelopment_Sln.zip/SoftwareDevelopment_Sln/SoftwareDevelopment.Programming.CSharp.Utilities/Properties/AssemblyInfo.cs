﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("SoftwareDevelopment.Programming.CSharp.Utilities")]
[assembly: AssemblyDescription("Utilities methods for common operations like serialization/deserialization, file & directory operrations, reading configuration file settings (from remote app.config as well), ADO .NET helpers, logging helpers and many more")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Łukasz Dąbrowski DABROWSKI SOFTWARE DEVELOPMENT")]
[assembly: AssemblyProduct("SoftwareDevelopment.Programming.CSharp.Utilities")]
[assembly: AssemblyCopyright("Copyright ©  2016")]
[assembly: AssemblyTrademark("https://github.com/dabrowski-software-development")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("64f58803-e00f-4cf5-9b2c-9d2f641a684a")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
<<<<<<< HEAD
[assembly: AssemblyVersion("4.0.0.2")]
[assembly: AssemblyFileVersion("4.0.0.2")]
=======
[assembly: AssemblyVersion("4.0.0.1")]
[assembly: AssemblyFileVersion("4.0.0.1")]
>>>>>>> dd92f80cb4ed057dd4c024214f2ed03b3c0ea27d
