﻿using System;
using System.Reflection;
using System.Text.RegularExpressions;

namespace SoftwareDevelopment.Programming.CSharp.Utilities
{
    /// <summary>
    /// Util class for common regular expression operations.
    /// </summary>
    [Obfuscation(ApplyToMembers = true, Exclude = false, StripAfterObfuscation = true)]
    public static class RegexUtils
    {

    }
}
