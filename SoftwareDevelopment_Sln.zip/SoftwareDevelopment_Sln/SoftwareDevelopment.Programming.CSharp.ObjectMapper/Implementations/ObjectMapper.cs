﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Security.Cryptography;
using System.Threading;

using SoftwareDevelopment.Programming.CSharp.Utilities;

using SoftwareDevelopment.Programming.CSharp.ObjectMapper.InternalDataStorage;


namespace SoftwareDevelopment.Programming.CSharp.ObjectMapper.Implementations
{
    /// <summary>
    /// Generic ObjectMapper class allowiing for mapping SQL query result to client POCO object or collection of objects.
    /// </summary>
    /// <typeparam name="T">source object for ObjectMapper class</typeparam>
    public class ObjectMapper<T> where T : class, new()
    {
        private ObjectMapper() {}

        /// <summary>
        /// Tries to establish connection to a database for subsequent mapping operation.
        /// This method is only required to be invoked, if you need to connect to database to execute a query.
        /// </summary>
        /// <param name="databaseConnectionStringKey">App.config ConnectionStrings' section key</param>
        /// <param name="connectionToInitialize">SqlConnection object to initialize</param>
        /// <param name="encrypted">specifies whether connection string is encrypted</param>
        /// <param name="userRsaPrivateKey">RSAParameters user private key to provide decryption capabilities</param>
        /// <returns></returns>
        public bool TryInitalizeDatabaseConnection(string databaseConnectionStringKey, out SqlConnection connectionToInitialize, bool encrypted = false, RSAParameters? userRsaPrivateKey = null)
        {
            string connectionString = ConfigurationUtils.GetConfigurationFileConnectionStringValue(databaseConnectionStringKey, encrypted, userRsaPrivateKey.HasValue ? userRsaPrivateKey.Value : new RSAParameters());

            try
            {
                connectionToInitialize = DatabaseUtils.CreateAndOptionallyOpenSqlServerConnection(connectionString, true);

                if (connectionToInitialize != null)
                    return true;
                return false;
            }
            catch (Exception exception)
            {
                exception = null;
                connectionToInitialize = null;
                return false;
            }
        }

        /// <summary>
        /// Maps SQL query result to client object.
        /// </summary>
        /// <param name="objectInstance">ObjectMapper's source object instance</param>
        /// <param name="sqlQuery">SQL query to execute against a database</param>
        /// <param name="opendConnectionInstance">instance of SqlConnection object which is by this time already opened</param>
        /// <param name="commandType">specifies type of SQL command</param>
        /// <param name="commandTimeout">specifies command timeout</param>
        /// <param name="commandBehavior">specifies command behaviour</param>
        /// <param name="closeDataReader">specifies command close IDataReader object after all data has been read</param>
        /// <returns>List of T</returns>
        public static List<T> MapSqlQueryResultToObject(T objectInstance, string sqlQuery, SqlConnection opendConnectionInstance,
                                             CommandType commandType = CommandType.Text, int commandTimeout = 3600, CommandBehavior commandBehavior = CommandBehavior.Default, bool closeDataReader = true)
        {
            if (objectInstance == null)
                return new List<T> {};

            return MapSqlQueryResultToObject(new List<T> { objectInstance }, sqlQuery, opendConnectionInstance, commandType, commandTimeout, commandBehavior, closeDataReader);
        }

        /// <summary>
        /// Maps SQL query result to client object.
        /// </summary>
        /// <param name="objectInstanceList">collection of ObjectMapper's source object instance</param>
        /// <param name="sqlQuery">SQL query to execute against a database</param>
        /// <param name="opendConnectionInstance">instance of SqlConnection object which is by this time already opened</param>
        /// <param name="commandType">specifies type of SQL command</param>
        /// <param name="commandTimeout">specifies command timeout</param>
        /// <param name="commandBehavior">specifies command behaviour</param>
        /// <param name="closeDataReader">specifies command close IDataReader object after all data has been read</param>
        /// <returns>List of T</returns>
        public static List<T> MapSqlQueryResultToObject(List<T> objectInstanceList, string sqlQuery, SqlConnection opendConnectionInstance,
                                             CommandType commandType = CommandType.Text, int commandTimeout = 3600, CommandBehavior commandBehavior = CommandBehavior.Default, bool closeDataReader = true)
        {
            if (objectInstanceList == null)
                return new List<T> {};

            IDbCommand command = DatabaseUtils.CreateSqlCommand(opendConnectionInstance, sqlQuery, commandType, commandTimeout);
            IDataReader reader = command.ExecuteReader(commandBehavior);

            return ConvertDataReaderDataToObjectRepresenation(objectInstanceList, reader, closeDataReader);
        }



        #region Util methods
        private static List<T> ConvertDataReaderDataToObjectRepresenation(List<T> objectInstanceList, IDataReader dataReader, bool closeDataReader)
        {
            List<RowObjectInternal> rowList = new List<RowObjectInternal>();

            while (dataReader.Read())
            {
                var row = new RowObjectInternal();

                for (int i = 0; i < dataReader.FieldCount; i++)
                {

                    row.Columns.Add(
                                        new ColumnObjectInternal
                                        {
                                            ColumnName = dataReader.GetName(i),
                                            Value = dataReader.GetValue(i)
                                        }
                                   );
                }
                rowList.Add(row);
            }

            if (closeDataReader)
                DatabaseUtils.CloseDataReader(dataReader);

            if (rowList.Count == 0)
                return objectInstanceList;


            Type objectInstanceType = typeof (T);

            rowList.ForEach(row => MapSqlDataObjectRepresentationToClientObject(row, objectInstanceType, objectInstanceList));

            return objectInstanceList;
        }



        private static void MapSqlDataObjectRepresentationToClientObject(RowObjectInternal row, Type objectInstanceType, List<T> objectInstanceList)
        {
            T t = new T();

            foreach (ColumnObjectInternal column in row.Columns)
            {
                MethodInfo setter = objectInstanceType.GetProperty(column.ColumnName, BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Public).GetSetMethod();

                setter.Invoke(t, BindingFlags.SetProperty, null, new[] { column.Value }, Thread.CurrentThread.CurrentUICulture);
            }
            objectInstanceList.Add(t);
        }
        #endregion



        private static ObjectMapper<T> _instance = null;
        /// <summary>
        /// Provides singleton for ObjectMapper.
        /// </summary>
        public static ObjectMapper<T> Instance
        {
            get
            {
                return _instance ?? new ObjectMapper<T>();
            }
        }
    }
}
