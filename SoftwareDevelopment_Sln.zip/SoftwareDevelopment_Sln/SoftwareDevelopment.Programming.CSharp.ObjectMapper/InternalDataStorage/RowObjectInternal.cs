﻿using System.Collections.Generic;

namespace SoftwareDevelopment.Programming.CSharp.ObjectMapper.InternalDataStorage
{
    class RowObjectInternal
    {
        public List<ColumnObjectInternal> Columns { get; set; } = new List<ColumnObjectInternal>();
    }
}
