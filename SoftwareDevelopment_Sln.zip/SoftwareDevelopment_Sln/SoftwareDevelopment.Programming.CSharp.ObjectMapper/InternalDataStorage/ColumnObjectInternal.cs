﻿using System;

namespace SoftwareDevelopment.Programming.CSharp.ObjectMapper.InternalDataStorage
{
    class ColumnObjectInternal
    {
        public string ColumnName { get; set; } = String.Empty;

        public object Value { get; set; } = null;
    }
}
